---
name: test-skill
description: use this when asked to test skill
---

woah this is a test skill
